export const environment = {
  production: true,
  BASE_URL: 'http://192.168.1.173'
};
